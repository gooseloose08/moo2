STEVESMODS: <br>
Unity 2018 2D Happy Wheels Hill Climb Clone <br>

I used a cool existing online project to start my Happy Wheels experiments with. <br>
Original Authors example:<br>
--- Make your own HILL CLIMB RACING ---- <br>
https://www.youtube.com/watch?v=DgG9us3QkTE <br>
NOTE: You will need to watch this video, download the project and get it running before copying over my changes <br>

---My Changes: <br>
<p>
This was a great example to start off with, alot of knowledge was baked into the demo, but it had flaws I wanted to correct. 
  
  1. I re-aranged the car parts to give better car physics
  2. I added game objects to re-start the game if the driver dies (falls on head)
  3. I added colliders and hinges to the drivers head in order to get the "bobble head effect" 
  4. Added colliders / bumpers with physics materials so the car would not get stuck in strange positions
  5. Added "thruster" with partical effect to get "airborn"
  6. Added longer course by copy/flipping existing terrain.
  
The game is actually playable now and a good start for the next person to take and run with

Thanks to the original author for sharing

Enjoy
</p>
